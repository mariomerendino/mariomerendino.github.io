Author: Mario J. Merendino
Desc: This is a program that runs the various sorting algorithms and tracks their runtimes
      On 3 different arrays of size [50], [100], and [200] elements

You can either double click the sorting file or open a terminal and run ./sorting

Questions? Email me at mariomerendino@gmail.com